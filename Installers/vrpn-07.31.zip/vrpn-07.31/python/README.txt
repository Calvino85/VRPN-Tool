This directory contains submissions from Damien Touraine that implements a Python interface to VRPN.  There is a SWIG-produced interface in ../vrpn_python that works with Python 2.7.  The version in this directory is hand-coded and works with both Python 2.7 and Python 3.

