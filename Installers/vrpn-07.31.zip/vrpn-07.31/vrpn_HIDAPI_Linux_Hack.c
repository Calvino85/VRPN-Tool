// This is here to get the correct .c file.

#include "submodules/hidapi/linux/hid-libusb.c"
